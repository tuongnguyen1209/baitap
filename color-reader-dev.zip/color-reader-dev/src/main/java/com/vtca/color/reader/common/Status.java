package com.vtca.color.reader.common;

public enum Status {
    OK, FAILED
}
