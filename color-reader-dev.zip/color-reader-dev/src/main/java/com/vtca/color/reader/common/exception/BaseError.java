package com.vtca.color.reader.common.exception;

public interface BaseError {
    String getCode();
    String getMessage();
}
