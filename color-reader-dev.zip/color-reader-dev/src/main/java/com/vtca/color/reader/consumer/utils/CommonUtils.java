package com.vtca.color.reader.consumer.utils;

import lombok.experimental.UtilityClass;

@UtilityClass
public class CommonUtils {
    public String getSpecificTextDemo(String s) {
        return "testing";
    }
}
