package com.vtca.color.reader.consumer.domain.color.reference;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ColorReferenceConstant {

}
