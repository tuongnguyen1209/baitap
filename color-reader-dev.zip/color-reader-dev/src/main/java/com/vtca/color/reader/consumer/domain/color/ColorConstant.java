package com.vtca.color.reader.consumer.domain.color;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ColorConstant {

}
