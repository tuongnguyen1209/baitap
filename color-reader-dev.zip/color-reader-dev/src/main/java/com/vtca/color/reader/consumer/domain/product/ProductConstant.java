package com.vtca.color.reader.consumer.domain.product;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ProductConstant {

}
