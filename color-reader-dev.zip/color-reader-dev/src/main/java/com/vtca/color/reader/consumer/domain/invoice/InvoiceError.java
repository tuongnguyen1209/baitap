package com.vtca.color.reader.consumer.domain.invoice;

import com.vtca.color.reader.common.exception.BaseError;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@ToString
public enum InvoiceError implements BaseError {
    INVOICE_INVALID("INVOICE_INVALID", "Invoice is invalid");

    private String code;
    private String message;

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }
}
