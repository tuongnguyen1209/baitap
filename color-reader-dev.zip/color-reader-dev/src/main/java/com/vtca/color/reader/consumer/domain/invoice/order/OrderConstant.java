package com.vtca.color.reader.consumer.domain.invoice.order;

import lombok.experimental.UtilityClass;

@UtilityClass
public class OrderConstant {

}
