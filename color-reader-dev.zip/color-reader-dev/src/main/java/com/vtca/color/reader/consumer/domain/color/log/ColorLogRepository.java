package com.vtca.color.reader.consumer.domain.color.log;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ColorLogRepository extends JpaRepository<ColorLog, Long> {

}
