package com.vtca.color.reader.consumer.integration;

public class ThirdPartyController {
}
