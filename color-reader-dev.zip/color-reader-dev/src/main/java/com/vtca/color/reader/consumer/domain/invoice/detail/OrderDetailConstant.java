package com.vtca.color.reader.consumer.domain.invoice.detail;

import lombok.experimental.UtilityClass;

@UtilityClass
public class OrderDetailConstant {

}
